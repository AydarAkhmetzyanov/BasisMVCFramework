<?php

//try {
//$creatives_siteDB = new PDO("mysql:host=localhost;dbname=creatives_site", 'creatives_site', 'sitepsw', 
//  array(
//    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
//    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"
//  ));
//include here your PDO database connection objects

//SQL for mysql demo
//CREATE TABLE demo ( id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, name TEXT , posts TEXT  );
//}
//catch(PDOException $e) {  
//    echo $e->getMessage();
//	exit();
//}