<?php

error_reporting(E_ALL);
ini_set('display_errors','On');

define ('DEVELOPMENT_ENVIRONMENT',true);
define ('DEFAULT_CONTROLLER_PATH','doc');
