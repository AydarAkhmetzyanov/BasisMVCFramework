      <hr>
      <footer>
       <p><a href="http://creativestripe.ru/">Интерактивное Агентство CreativeStripe &copy; 2012</a></p>
      </footer>
    </div>
<?= HTML::includeJS('bootstrap.min');?>
  </body>
</html>