<?php
class Model{
	
}